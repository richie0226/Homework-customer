package com.richie;

import java.util.Date;

public class Car {
    String id;
    Date enter;
    public Car(String id){

    }
}
