package com.richie;

public class MapTester {
}
